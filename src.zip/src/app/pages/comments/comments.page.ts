import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Location } from "@angular/common";


@Component({
  selector: 'app-comments',
  templateUrl: './comments.page.html',
  styleUrls: ['./comments.page.scss'],
})
export class CommentsPage implements OnInit {


  id: any;
  //this.router.navigate(["/tabs/search"]);
  constructor(private router: ActivatedRoute, private location: Location) {
      this.id = this.router.params.subscribe(params => {
      this.id = params['id']; 
      console.log("Id: ", this.id);
    });
  }

  ngOnInit() {

  }


  BackPage(){
    this.location.back();
    //this.router.navigate(["/tabs/search"]);
  }

}
