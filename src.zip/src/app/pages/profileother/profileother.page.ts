import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profileother',
  templateUrl: './profileother.page.html',
  styleUrls: ['./profileother.page.scss'],
})
export class ProfileotherPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
