import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postpop',
  templateUrl: './postpop.component.html',
  styleUrls: ['./postpop.component.scss'],
})
export class PostpopComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
